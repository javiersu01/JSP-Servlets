package com.empresa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.empresa.dao.ClienteDAO;
import com.model.Cliente;

/**
 * Servlet implementation class ClienteController
 */
@WebServlet("/")
public class ClienteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClienteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getServletPath();
		
		switch (action) {
		case "/add":
			addCliente(request, response);
			break;
		case "/update":
			updateCliente(request, response);
			break;

		default:
			listCliente(request, response);
			break;
		}//cierra switch
	
	}// cierre doGet

	private void listCliente(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void updateCliente(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void addCliente(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		int codigo_cliente=Integer.parseInt(request.getParameter("codigo_cliente"));
		String nombre=request.getParameter("nombre");
		String ciudad=request.getParameter("ciudad");
		float facturacion=Float.parseFloat(request.getParameter("facturacion"));
		Cliente cliente=new Cliente(codigo_cliente, nombre, ciudad, facturacion);
		ClienteDAO dao=new ClienteDAO();
		dao.insertCliente(cliente);
		if (facturacion < 100 ) {
			
		}//cierre if
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
