package com.model;

public class Cliente {
	public int codigo_cliente;
	public String nombre;
	public String ciudad;
	public float facturacion;
	public Cliente(int codigo_cliente, String nombre, String ciudad, float facturacion) {
		super();
		this.codigo_cliente = codigo_cliente;
		this.nombre = nombre;
		this.ciudad = ciudad;
		this.facturacion = facturacion;
	}
	public int getCodigo_cliente() {
		return codigo_cliente;
	}
	public void setCodigo_cliente(int codigo_cliente) {
		this.codigo_cliente = codigo_cliente;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	public float getFacturacion() {
		return facturacion;
	}
	public void setFacturacion(float facturacion) {
		this.facturacion = facturacion;
	}
	

	
} // cierre clase 
